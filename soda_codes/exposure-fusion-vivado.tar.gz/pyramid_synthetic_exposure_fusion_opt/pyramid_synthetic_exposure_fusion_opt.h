#pragma once


#include "hw_classes.h"

void pyramid_synthetic_exposure_fusion_opt(HWStream<hw_uint<32> >& /* get_args num ports = 1 */in_off_chip, HWStream<hw_uint<32> >& /* get_args num ports = 1 */pyramid_synthetic_exposure_fusion);
